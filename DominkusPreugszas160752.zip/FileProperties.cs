﻿namespace Lab1
{
    public enum FileProperties
    {
        ReadOnly,
        Archive,
        System,
        Hidden,
        None,
    }
}